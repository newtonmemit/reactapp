export const TRUCKS_NODE = 'trucks';
export const DRIVERS_NODE = 'drivers';
export const MATERIALS_NODE = 'materials';
export const TRIPS_NODE = 'trips';
